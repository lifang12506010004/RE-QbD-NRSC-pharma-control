function J_u = compute_gradient(y_ss, params)
%% compute_gradient - 计算经济目标函数的梯度
%   输入:  y_ss - 稳态输出预测 [Q30; CU]
%         params - 参数结构体
%   输出:  J_u - 梯度向量 [dJ/du1; dJ/du2]
%
%   经济目标: J = c'u + alpha * ||y - y_target||^2_Q

y_target = [params.target_Q30; params.target_CU];
error = y_ss - y_target;

% 二次项梯度: d(||error||^2)/du = 2*alpha*Gy'*Q*error
J_u_quad = 2 * params.alpha * params.Gy' * params.Q * error;

% 线性项梯度 (假设 c = [0.1; 0.05])
c = [0.1; 0.05];
J_u = c + J_u_quad;

end
