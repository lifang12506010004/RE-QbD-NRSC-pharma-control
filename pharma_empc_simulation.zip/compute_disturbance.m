function d = compute_disturbance(t, disturbance)
%% compute_disturbance - 计算当前时刻的扰动值
%   输入:  t - 当前时间 [h]
%         disturbance - 扰动结构体
%   输出:  d - 扰动值
%
%   扰动模型: 阶跃扰动 + 指数衰减

d = 0;
for i = 1:length(disturbance.times)
    if t >= disturbance.times(i)
        % 指数衰减的阶跃扰动
        tau_decay = 2;  % 衰减时间常数 [h]
        d = d + disturbance.magnitudes(i) * exp(-(t - disturbance.times(i))/tau_decay);
    end
end

end
