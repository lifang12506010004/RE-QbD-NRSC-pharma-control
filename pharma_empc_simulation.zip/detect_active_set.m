function [active_set, constraints] = detect_active_set(y_ss, params)
%% detect_active_set - 检测活跃约束集
%   输入:  y_ss - 稳态输出预测 [Q30; CU]
%         params - 参数结构体
%   输出:  active_set - 活跃集标识 (0=None, 1=g1, 2=g2, 3=g3, 4=Multiple)
%         constraints - 约束值向量

Q30_ss = y_ss(1);
CU_ss = y_ss(2);

% 计算约束值
% g1: Q30 >= Q30_min  =>  Q30 - Q30_min >= 0
g1 = Q30_ss - params.Q30_min;
% g2: Q30 <= Q30_max  =>  Q30_max - Q30 >= 0
g2 = params.Q30_max - Q30_ss;
% g3: CU >= CU_min    =>  CU - CU_min >= 0
g3 = CU_ss - params.CU_min;

constraints = [g1; g2; g3];

% 活跃集判断 (epsilon-容差)
eps = params.epsilon;
active = [];
if g1 < eps
    active = [active, 1];
end
if g2 < eps
    active = [active, 2];
end
if g3 < eps
    active = [active, 3];
end

if isempty(active)
    active_set = 0;
elseif length(active) == 1
    active_set = active(1);
else
    active_set = 4;  % Multiple constraints active
end

end
