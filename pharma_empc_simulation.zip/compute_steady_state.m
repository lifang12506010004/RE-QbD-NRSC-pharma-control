function y_ss = compute_steady_state(u, d, params)
%% compute_steady_state - 计算稳态输出预测
%   输入:  u - 操纵变量 [u1; u2]
%         d - 扰动值
%         params - 参数结构体
%   输出:  y_ss - 稳态输出 [Q30; CU]
%
%   基于线性化稳态模型: y_ss = y* + Gy*(u - u*) + Gd*d

y_star = [params.target_Q30; params.target_CU];
u_star = [params.u1_nom; params.u2_nom];

y_ss = y_star + params.Gy * (u - u_star) + params.Gd * d;

% 添加物理约束
y_ss(1) = max(params.Q30_min - 5, min(params.Q30_max + 5, y_ss(1)));
y_ss(2) = max(params.CU_min - 5, min(105, y_ss(2)));

end
