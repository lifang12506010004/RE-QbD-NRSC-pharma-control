function generate_figure3(t, x, active_set_history, economic_loss_history, params, disturbance)
%% generate_figure3 - 生成 Fig 3: 24小时动态轨迹
%   输入:  t - 时间向量 [h]
%         x - 状态矩阵 [N x 4]
%         active_set_history - 活跃集历史
%         economic_loss_history - 经济损失历史
%         params - 参数结构体
%         disturbance - 扰动结构体

Q30 = x(:, 1);
CU = x(:, 2);
u1 = x(:, 3);
u2 = x(:, 4);

% 平滑活跃集 (减少噪声导致的频繁切换)
window = 15;
Q30_smooth = smoothdata(Q30, 'movmean', window);
CU_smooth = smoothdata(CU, 'movmean', window);

% 重新计算平滑后的活跃集
epsilon_tol = 1.5;
active_set_smooth = zeros(length(t), 1);
for i = 1:length(t)
    g1 = Q30_smooth(i) - params.Q30_min;
    g2 = params.Q30_max - Q30_smooth(i);
    g3 = CU_smooth(i) - params.CU_min;

    active = [];
    if g1 < epsilon_tol, active = [active, 1]; end
    if g2 < epsilon_tol, active = [active, 2]; end
    if g3 < epsilon_tol, active = [active, 3]; end

    if isempty(active)
        active_set_smooth(i) = 0;
    elseif length(active) == 1
        active_set_smooth(i) = active(1);
    else
        active_set_smooth(i) = 4;
    end
end

% 创建图形
fig = figure('Position', [100, 50, 1200, 1100], 'Color', 'w');

% 颜色
c_Q30 = [0.12, 0.47, 0.71];
c_CU = [0.58, 0.23, 0.44];
c_u1 = [1.00, 0.50, 0.05];
c_u2 = [0.84, 0.15, 0.16];
c_loss = [0.17, 0.63, 0.17];

% Panel 1: Q30
ax1 = subplot(6, 1, 1);
plot(t, Q30, 'Color', c_Q30, 'LineWidth', 0.8);
hold on;
yline(params.target_Q30, '--', 'Color', [0.5, 0.5, 0.5], 'LineWidth', 0.7, 'Alpha', 0.6);
fill([t, fliplr(t)], [100*ones(size(t)), 115*ones(size(t))], 'r', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
fill([t, fliplr(t)], [70*ones(size(t)), 80*ones(size(t))], 'r', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
for i = 1:length(disturbance.times)
    xline(disturbance.times(i), ':', 'Color', 'r', 'LineWidth', 0.7, 'Alpha', 0.35);
end
ylabel('$Q_{30}$ (mg)', 'Interpreter', 'latex', 'FontSize', 11);
ylim([72, 112]);
legend('$Q_{30}$', 'Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 9);
grid on; grid minor;
ax1.GridAlpha = 0.2;
set(gca, 'XTickLabel', []);

% Panel 2: CU
ax2 = subplot(6, 1, 2);
plot(t, CU, 'Color', c_CU, 'LineWidth', 0.8);
hold on;
yline(params.target_CU, '--', 'Color', [0.5, 0.5, 0.5], 'LineWidth', 0.7, 'Alpha', 0.6);
fill([t, fliplr(t)], [90*ones(size(t)), 95*ones(size(t))], 'r', 'FaceAlpha', 0.05, 'EdgeColor', 'none');
for i = 1:length(disturbance.times)
    xline(disturbance.times(i), ':', 'Color', 'r', 'LineWidth', 0.7, 'Alpha', 0.35);
end
ylabel('CU (\%)', 'Interpreter', 'latex', 'FontSize', 11);
ylim([89, 106]);
legend('CU', 'Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 9);
grid on; grid minor;
ax2.GridAlpha = 0.2;
set(gca, 'XTickLabel', []);

% Panel 3: u1
ax3 = subplot(6, 1, 3);
plot(t, u1, 'Color', c_u1, 'LineWidth', 0.8);
hold on;
yline(params.u1_nom, '--', 'Color', [0.5, 0.5, 0.5], 'LineWidth', 0.7, 'Alpha', 0.6);
for i = 1:length(disturbance.times)
    xline(disturbance.times(i), ':', 'Color', 'r', 'LineWidth', 0.7, 'Alpha', 0.35);
end
ylabel('$u_1$ (rpm)', 'Interpreter', 'latex', 'FontSize', 11);
ylim([75, 165]);
legend('$u_1$', 'Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 9);
grid on; grid minor;
ax3.GridAlpha = 0.2;
set(gca, 'XTickLabel', []);

% Panel 4: u2
ax4 = subplot(6, 1, 4);
plot(t, u2, 'Color', c_u2, 'LineWidth', 0.8);
hold on;
yline(params.u2_nom, '--', 'Color', [0.5, 0.5, 0.5], 'LineWidth', 0.7, 'Alpha', 0.6);
for i = 1:length(disturbance.times)
    xline(disturbance.times(i), ':', 'Color', 'r', 'LineWidth', 0.7, 'Alpha', 0.35);
end
ylabel('$u_2$ (kN)', 'Interpreter', 'latex', 'FontSize', 11);
ylim([9, 23]);
legend('$u_2$', 'Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 9);
grid on; grid minor;
ax4.GridAlpha = 0.2;
set(gca, 'XTickLabel', []);

% Panel 5: Active Set
ax5 = subplot(6, 1, 5);
hold on;

% 背景色带
colors_bg = {[0.91, 0.96, 0.91]; [1.00, 0.80, 0.82]; [1.00, 0.88, 0.70]; [0.88, 0.75, 0.91]; [0.70, 0.87, 0.86]};
labels = {'None', '$g_1$', '$g_2$', '$g_3$', 'Multiple'};

for val = 0:4
    mask = (active_set_smooth == val);
    if any(mask)
        starts = find(diff([0; mask]) == 1);
        ends = find(diff([mask; 0]) == -1);
        for j = 1:length(starts)
            s = max(1, starts(j)-1);
            e = min(length(t), ends(j));
            fill([t(s), t(e), t(e), t(s)], [val-0.4, val-0.4, val+0.4, val+0.4], ...
                 colors_bg{val+1}, 'FaceAlpha', 0.5, 'EdgeColor', 'none');
        end
    end
end

stairs(t, active_set_smooth, 'Color', [0.2, 0.2, 0.2], 'LineWidth', 1.5);
ylim([-0.5, 4.5]);
yticks(0:4);
yticklabels(labels);
ylabel('Active Set', 'Interpreter', 'latex', 'FontSize', 11);
for i = 1:length(disturbance.times)
    xline(disturbance.times(i), ':', 'Color', 'r', 'LineWidth', 0.7, 'Alpha', 0.35);
end
grid on; grid minor;
ax5.GridAlpha = 0.2;
set(gca, 'XTickLabel', []);

% Panel 6: Economic Loss
ax6 = subplot(6, 1, 6);
plot(t, economic_loss_history, 'Color', c_loss, 'LineWidth', 0.8);
hold on;
fill([t, fliplr(t)], [zeros(size(t)), economic_loss_history'], c_loss, 'FaceAlpha', 0.12, 'EdgeColor', 'none');
for i = 1:length(disturbance.times)
    xline(disturbance.times(i), ':', 'Color', 'r', 'LineWidth', 0.7, 'Alpha', 0.35);
end
ylabel('Economic loss (\%)', 'Interpreter', 'latex', 'FontSize', 11);
xlabel('Time (h)', 'Interpreter', 'latex', 'FontSize', 11);
ylim([0, max(economic_loss_history)*1.15]);
legend('Economic loss', 'Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 9);
grid on; grid minor;
ax6.GridAlpha = 0.2;

% 保存
exportgraphics(fig, 'figures/Fig3_transient.png', 'Resolution', 300);
close(fig);

fprintf('Fig 3 saved to figures/Fig3_transient.png\n');

end
