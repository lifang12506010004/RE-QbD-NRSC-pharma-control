%% ============================================================
%  Pharmaceutical Continuous Manufacturing EMPC Simulation
%  制药连续制造经济模型预测控制仿真
%  ============================================================
%  Author: [Your Name]
%  Date: 2024
%  Description: 
%    This script implements the proposed active-set EMPC scheme
%    for a continuous direct compression pharmaceutical process.
%    It generates the 24-hour dynamic trajectories (Fig. 3) and
%    sensitivity analysis (Fig. 4) presented in the paper.
%  ============================================================

clear; clc; close all;

%% 0. 添加路径
addpath('utils');
addpath('models');
addpath('plots');

%% 1. 仿真参数设置
fprintf('=== Pharmaceutical CM EMPC Simulation ===\n');
fprintf('Initializing parameters...\n');

% 时间参数
T_sim = 24;              % 总仿真时间 [h]
Ts = 1/60;               % 采样时间 [h] = 1 min
t = 0:Ts:T_sim;          % 时间向量
N = length(t);           % 总步数

% 过程参数 (基于连续压片工艺)
params.target_Q30 = 85;   % 目标片重 [mg]
params.target_CU = 98.5; % 目标含量均匀度 [%]
params.u1_nom = 120;     % 螺杆转速标称值 [rpm]
params.u2_nom = 15;      % 压缩力标称值 [kN]

% 约束
params.Q30_min = 80;     % 片重下限 [mg]
params.Q30_max = 100;    % 片重上限 [mg]
params.CU_min = 95;      % 含量均匀度下限 [%]
params.u1_min = 80;      % 螺杆转速下限 [rpm]
params.u1_max = 160;     % 螺杆转速上限 [rpm]
params.u2_min = 10;      % 压缩力下限 [kN]
params.u2_max = 22;      % 压缩力上限 [kN]

% EMPC 参数
params.N_sw = 30;        % 切换窗口
params.epsilon = 0.05;   % 活跃集容差
params.alpha = 1.0;      % 经济项权重
params.Q = diag([1, 1]); % 输出权重矩阵

% 扰动设置
disturbance.times = [4, 8, 14, 19];        % 扰动发生时间 [h]
disturbance.magnitudes = [12, -8, 15, -10]; % 扰动幅值

% 噪声
params.sigma_Q30 = 1.5;  % Q30 测量噪声标准差
params.sigma_CU = 0.8;   % CU 测量噪声标准差
params.sigma_u1 = 2.0;   % u1 执行噪声标准差
params.sigma_u2 = 0.3;   % u2 执行噪声标准差

%% 2. 初始化状态
fprintf('Initializing states...\n');
x = zeros(N, 4);         % [Q30, CU, u1, u2]
x(1, :) = [params.target_Q30, params.target_CU, params.u1_nom, params.u2_nom];

% 活跃集记录
active_set_history = zeros(N, 1);
economic_loss_history = zeros(N, 1);
solve_time_history = zeros(N, 1);

% 增益矩阵 (线性化模型)
params.Gy = [0.8, -0.3;   % Q30 对 u1, u2 的增益
             0.2,  0.5];  % CU  对 u1, u2 的增益
params.Gd = [0.5;         % Q30 对扰动的增益
             0.3];        % CU  对扰动的增益

%% 3. 主仿真循环
fprintf('Running simulation...\n');
tic;

for k = 1:N-1
    % 当前状态
    Q30_k = x(k, 1);
    CU_k = x(k, 2);
    u1_k = x(k, 3);
    u2_k = x(k, 4);

    % 计算扰动
    d_k = compute_disturbance(t(k), disturbance);

    % 计算稳态预测
    y_ss = compute_steady_state([u1_k; u2_k], d_k, params);

    % 计算梯度估计
    J_u = compute_gradient(y_ss, params);

    % 活跃集检测
    [active_set_k, constraints] = detect_active_set(y_ss, params);
    active_set_history(k) = active_set_k;

    % 求解 EMPC 优化问题
    tic_solve = tic;
    du = solve_empc(J_u, active_set_k, constraints, params);
    solve_time_history(k) = toc(tic_solve);

    % 更新操纵变量
    u1_new = max(params.u1_min, min(params.u1_max, u1_k + du(1)));
    u2_new = max(params.u2_min, min(params.u2_max, u2_k + du(2)));

    % 添加执行噪声
    u1_new = u1_new + params.sigma_u1 * randn;
    u2_new = u2_new + params.sigma_u2 * randn;

    % 过程动态 (一阶滞后 + 扰动)
    tau_Q30 = 0.5;   % Q30 时间常数 [h]
    tau_CU = 0.167;  % CU 时间常数 [h] (10 min)

    dQ30 = (y_ss(1) - Q30_k) / tau_Q30 * Ts;
    dCU = (y_ss(2) - CU_k) / tau_CU * Ts;

    Q30_new = Q30_k + dQ30 + params.sigma_Q30 * randn;
    CU_new = CU_k + dCU + params.sigma_CU * randn;

    % 记录状态
    x(k+1, :) = [Q30_new, CU_new, u1_new, u2_new];

    % 计算经济损失
    economic_loss_history(k) = compute_economic_loss(x(k+1, :), params);

    % 进度显示
    if mod(k, 60) == 0
        fprintf('  Progress: %.1f%% (t = %.1f h)\n', k/N*100, t(k));
    end
end

sim_time = toc;
fprintf('Simulation completed in %.2f s\n', sim_time);

%% 4. 保存结果
fprintf('Saving results...\n');
save('results/simulation_results.mat', 't', 'x', 'active_set_history', ...
     'economic_loss_history', 'solve_time_history', 'params', 'disturbance');

%% 5. 生成图表
fprintf('Generating figures...\n');
generate_figure3(t, x, active_set_history, economic_loss_history, params, disturbance);
generate_figure4(params);

fprintf('=== Simulation Complete ===\n');
