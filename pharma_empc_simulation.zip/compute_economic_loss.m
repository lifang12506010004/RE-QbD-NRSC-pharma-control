function loss = compute_economic_loss(x, params)
%% compute_economic_loss - 计算经济损失
%   输入:  x - 状态向量 [Q30, CU, u1, u2]
%         params - 参数结构体
%   输出:  loss - 经济损失 [%]

Q30 = x(1);
CU = x(2);
u1 = x(3);
u2 = x(4);

% 偏离目标的损失
loss_Q = 0.5 * ((Q30 - params.target_Q30) / params.target_Q30)^2;
loss_CU = 0.3 * ((CU - params.target_CU) / params.target_CU)^2;

% 操纵变量偏离的损失
loss_u = 0.1 * ((u1 - params.u1_nom) / params.u1_nom)^2 + ...
         0.1 * ((u2 - params.u2_nom) / params.u2_nom)^2;

% 总经济损失 (百分比)
loss = (loss_Q + loss_CU + loss_u) * 100;

end
