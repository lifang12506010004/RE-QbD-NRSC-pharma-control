# Pharmaceutical Continuous Manufacturing EMPC Simulation

制药连续制造经济模型预测控制仿真代码

## 项目简介

本项目包含论文中提出的 **Active-Set Economic Model Predictive Control (EMPC)** 方案的完整 MATLAB 仿真代码，用于制药连续直接压片工艺的过程优化。

## 文件结构

```
.
├── main_simulation.m          # 主仿真脚本
├── compute_disturbance.m      # 扰动计算函数
├── compute_steady_state.m     # 稳态预测函数
├── compute_gradient.m         # 经济梯度计算
├── detect_active_set.m        # 活跃约束检测
├── solve_empc.m              # EMPC 优化求解
├── compute_economic_loss.m    # 经济损失计算
├── generate_figure3.m         # Fig 3 绘图函数
├── generate_figure4.m         # Fig 4 绘图函数
├── README.md                 # 本文件
└── LICENSE                   # 许可证
```

## 系统要求

- **MATLAB R2020a 或更高版本**
- **Statistics and Machine Learning Toolbox** (用于 smoothdata)
- 建议内存: 4GB+
- 运行时间: 约 2-5 分钟 (取决于硬件)

## 快速开始

### 1. 下载代码

```bash
git clone https://github.com/[your-username]/pharma-empc-simulation.git
cd pharma-empc-simulation
```

### 2. 运行仿真

在 MATLAB 中执行:

```matlab
>> main_simulation
```

### 3. 查看结果

仿真完成后，结果将保存在:
- `results/simulation_results.mat` - 原始仿真数据
- `figures/Fig3_transient.png` - 24小时动态轨迹图
- `figures/Fig4_sensitivity.png` - 灵敏度分析图

## 模型描述

### 过程模型

连续压片工艺的状态变量:
- **Q30**: 片重 [mg]
- **CU**: 含量均匀度 [%]

操纵变量:
- **u1**: 螺杆转速 [rpm]
- **u2**: 压缩力 [kN]

### 经济目标函数

```
min J(u,d) = c^T u + alpha * ||y - y_target||^2_Q
```

### 约束

- 片重范围: 80 ≤ Q30 ≤ 100 mg
- 含量均匀度: CU ≥ 95%
- 螺杆转速: 80 ≤ u1 ≤ 160 rpm
- 压缩力: 10 ≤ u2 ≤ 22 kN

### 扰动场景

仿真包含 4 个阶跃扰动:
1. t = 4h: 原料流动性变化 (+12)
2. t = 8h: 环境湿度变化 (-8)
3. t = 14h: 设备磨损 (+15)
4. t = 19h: 原料批次变化 (-10)

## 参数说明

| 参数 | 默认值 | 描述 |
|:---|:---|:---|
| `N_sw` | 30 | 活跃集切换窗口 |
| `epsilon` | 0.05 | 活跃集容差 |
| `alpha` | 1.0 | 经济项权重 |
| `Ts` | 1 min | 采样时间 |
| `T_sim` | 24 h | 总仿真时间 |

## 自定义仿真

### 修改扰动场景

在 `main_simulation.m` 中编辑:

```matlab
disturbance.times = [4, 8, 14, 19];        % 扰动时间 [h]
disturbance.magnitudes = [12, -8, 15, -10]; % 扰动幅值
```

### 修改 EMPC 参数

```matlab
params.N_sw = 30;        % 切换窗口
params.epsilon = 0.05;   % 容差
params.alpha = 1.0;      % 权重
```

### 修改过程模型

在 `compute_steady_state.m` 中编辑增益矩阵:

```matlab
params.Gy = [0.8, -0.3;   % Q30 对 u1, u2 的增益
             0.2,  0.5];  % CU 对 u1, u2 的增益
```

## 引用

如果您在研究中使用了本代码，请引用:

```bibtex
@article{your_paper_2024,
  title={Active-Set EMPC for Pharmaceutical Continuous Manufacturing},
  author={[Your Name]},
  journal={[Journal Name]},
  year={2024}
}
```

## 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件。

## 联系方式

如有问题或建议，请通过 GitHub Issues 或邮件联系。

---

**注意**: 本代码为学术研究用途，仿真结果基于简化模型。实际工业应用需根据具体工艺调整参数。
