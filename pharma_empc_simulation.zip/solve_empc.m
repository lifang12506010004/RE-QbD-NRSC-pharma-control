function du = solve_empc(J_u, active_set, constraints, params)
%% solve_empc - 求解 EMPC 优化问题
%   输入:  J_u - 经济梯度
%         active_set - 活跃集标识
%         constraints - 约束值
%         params - 参数结构体
%   输出:  du - 操纵变量增量 [du1; du2]
%
%   优化问题: min  -du' * J_u
%            s.t.  G_A^g * du <= 0  (活跃约束保持)
%                  ||du|| <= Delta   (信任域)

% 信任域半径
delta_max = 20;  % 最大增量

if active_set == 0
    % 无活跃约束: 最速下降方向
    du = delta_max * J_u / norm(J_u);

elseif active_set == 1
    % g1 活跃 (Q30 下限): 保持 Q30 不下降
    % 即 Gy(1,:) * du >= 0
    A = -params.Gy(1, :);  % -Gy(1,:) * du <= 0
    b = 0;
    du = solve_qp(J_u, A, b, delta_max);

elseif active_set == 2
    % g2 活跃 (Q30 上限): 保持 Q30 不上升
    A = params.Gy(1, :);   % Gy(1,:) * du <= 0
    b = 0;
    du = solve_qp(J_u, A, b, delta_max);

elseif active_set == 3
    % g3 活跃 (CU 下限): 保持 CU 不下降
    A = -params.Gy(2, :);  % -Gy(2,:) * du <= 0
    b = 0;
    du = solve_qp(J_u, A, b, delta_max);

else
    % 多个约束活跃: 在零空间中求解
    % 简化为投影梯度法
    du = project_gradient(J_u, params.Gy, constraints, delta_max);
end

% 限制增量范围
du = max(-delta_max, min(delta_max, du));

end

%% 辅助函数: 求解带约束的 QP
function du = solve_qp(J_u, A, b, delta_max)
    % 解析求解: min -du'*J_u  s.t. A*du <= b, ||du|| <= delta_max
    % 使用拉格朗日乘子法

    % 先尝试无约束解
    du_unconstrained = delta_max * J_u / norm(J_u);

    if A * du_unconstrained <= b + 1e-6
        % 无约束解满足约束
        du = du_unconstrained;
    else
        % 约束活跃: 投影到约束边界
        % 简化处理: 沿梯度方向投影
        du_proj = du_unconstrained - (A * du_unconstrained - b) / (A * A') * A';
        if norm(du_proj) > delta_max
            du_proj = delta_max * du_proj / norm(du_proj);
        end
        du = du_proj;
    end
end

%% 辅助函数: 投影梯度
function du = project_gradient(J_u, Gy, constraints, delta_max)
    % 在多个约束的零空间中投影梯度
    % 简化实现: 使用最速下降并截断
    du = delta_max * J_u / norm(J_u);

    % 迭代投影
    for iter = 1:10
        for i = 1:length(constraints)
            if constraints(i) < 0.01
                % 约束接近边界, 投影
                if i == 1
                    A = -Gy(1, :);
                elseif i == 2
                    A = Gy(1, :);
                else
                    A = -Gy(2, :);
                end
                if A * du > 0
                    du = du - (A * du) / (A * A') * A';
                end
            end
        end
    end

    if norm(du) > delta_max
        du = delta_max * du / norm(du);
    end
end
